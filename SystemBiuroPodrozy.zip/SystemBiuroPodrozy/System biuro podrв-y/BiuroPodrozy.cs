﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;
using System_biuro_podróży;
using static Klient;
using static System_biuro_podróży.BrakMiejscException;
using static System_biuro_podróży.Przewodnik;
using static System_biuro_podróży.WycieczkaBase;

[Serializable]
public class BiuroPodrozy : IZarzadzanieKlientami, IZarzadzanieWycieczkami, IZarzadzaniePrzewodnikami, IZarzadzanieRezerwacjami, ICloneable
{
    public List<Klient> klienci = new List<Klient>();
    public List<Wycieczka> wycieczki = new List<Wycieczka>();
    public List<Przewodnik> przewodnicy = new List<Przewodnik>();
    public Rezerwacje rezerwacje = new Rezerwacje();

    // Implementacje interfejsu IZarzadzanieKlientami
    public void DodajKlienta(Klient klient)
    {
        klienci.Add(klient);
    }
    // Wyszukiwanie klienta
    public Klient ZnajdzKlienta(string id)
    {
        return klienci.FirstOrDefault(klient => klient.Id == id);
    }
    // Aktualizacja danych klienta
    public void AktualizujKlienta(string id, string noweImie, string noweNazwisko)
    {
        var klient = ZnajdzKlienta(id);
        if (klient != null)
        {
            klient.Imie = noweImie;
            klient.Nazwisko = noweNazwisko;
        }
    }
    // Usuwanie klienta
    public void UsunKlienta(string id)
    {
        var klientDoUsuniecia = ZnajdzKlienta(id);
        if (klientDoUsuniecia != null)
        {
            klienci.Remove(klientDoUsuniecia);
        }
    }

    // Metoda do wyświetlania wszystkich klientów (dla demonstracji)
    public void WyswietlKlientow()
    {
        foreach (var klient in klienci)
        {
            Console.WriteLine($"ID: {klient.Id}, Imię: {klient.Imie}, Nazwisko: {klient.Nazwisko}");
        }
    }

    // Implementacje interfejsu IZarzadzanieWycieczkami
    public void DodajWycieczke(Wycieczka wycieczka)
    {
        wycieczki.Add(wycieczka);
    }

    // Wyszukiwanie wycieczki
    public Wycieczka ZnajdzWycieczke(string id)
    {
        return wycieczki.FirstOrDefault(wycieczka => wycieczka.Id == id);
    }

    // Aktualizacja danych wycieczki
    public void AktualizujWycieczke(string id, string noweMiejsceDocelowe, decimal nowaCena)
    {
        var wycieczka = ZnajdzWycieczke(id);
        if (wycieczka != null)
        {
            wycieczka.MiejsceDocelowe = noweMiejsceDocelowe;
            wycieczka.Cena = nowaCena;
        }
    }

    // Usuwanie wycieczki
    public void UsunWycieczke(string id)
    {
        var wycieczkaDoUsuniecia = ZnajdzWycieczke(id);
        if (wycieczkaDoUsuniecia != null)
        {
            wycieczki.Remove(wycieczkaDoUsuniecia);
        }
    }

    // Metoda do wyświetlania wszystkich wycieczek (dla demonstracji)
    public void WyswietlWycieczki()
    {
        foreach (var wycieczka in wycieczki)
        {
            Console.WriteLine($"ID: {wycieczka.Id}, Miejsce: {wycieczka.MiejsceDocelowe}, Cena: {wycieczka.Cena}");
        }
    }

    // Implementacje interfejsu IZarzadzaniePrzewodnikami
    public void DodajPrzewodnika(Przewodnik przewodnik)
    {
        przewodnicy.Add(przewodnik);
    }

    public Przewodnik ZnajdzPrzewodnika(string id)
    {
        return przewodnicy.FirstOrDefault(przewodnik => przewodnik.Id == id);
    }

    public void AktualizujPrzewodnika(string id, string nowyTelefon, string nowaSpecjalizacja)
    {
        var przewodnik = ZnajdzPrzewodnika(id);
        if (przewodnik != null)
        {
            przewodnik.AktualizujDanePrzewodnika(nowyTelefon, nowaSpecjalizacja);
        }
    }

    public void UsunPrzewodnika(string id)
    {
        var przewodnikDoUsuniecia = ZnajdzPrzewodnika(id);
        if (przewodnikDoUsuniecia != null)
        {
            przewodnicy.Remove(przewodnikDoUsuniecia);
        }
    }

    public void WyswietlPrzewodnikow()
    {
        foreach (var przewodnik in przewodnicy)
        {
            Console.WriteLine($"ID: {przewodnik.Id}, Imię: {przewodnik.Imie}, Nazwisko: {przewodnik.Nazwisko}");
        }
    }

    public void WybierzPrzewodnika(string klientId, string przewodnikId)
    {
        var klient = ZnajdzKlienta(klientId);
        var przewodnik = ZnajdzPrzewodnika(przewodnikId);

        if (klient != null && przewodnik != null)
        {
            Console.WriteLine($"Klient o ID {klientId} wybrał przewodnika o ID {przewodnikId}.");
        }
        else
        {
            Console.WriteLine("Nie można dokonać wyboru - klient lub przewodnik nie istnieje.");
        }
    }

    // Implementacje interfejsu IZarzadzanieRezerwacjami
    public void ZarezerwujWycieczke(Klient klient, string wycieczkaId)
    {
        var wycieczka = ZnajdzWycieczke(wycieczkaId);

        if (klient != null && wycieczka != null)
        {
            if (wycieczka.LiczbaMiejsc > 0)
            {
                rezerwacje.ZarezerwujWycieczke(klient, wycieczka);
                wycieczka.LiczbaMiejsc--;
            }
            else
            {
                throw new BrakMiejscException("Brak wystarczającej liczby miejsc na wycieczce.");
            }
        }
        else
        {
            Console.WriteLine("Nie można zarezerwować wycieczki - klient lub wycieczka nie istnieje.");
        }

    }

    public void WyswietlRezerwacje()
    {
        rezerwacje.WyswietlRezerwacje();
    }

    public void AnulujRezerwacje(Klient klient, string wycieczkaId)
    {
        var wycieczka = ZnajdzWycieczke(wycieczkaId);

        if (klient != null && wycieczka != null)
        {
            rezerwacje.AnulujRezerwacje(klient, wycieczka);
        }
        else
        {
            Console.WriteLine("Nie można anulować rezerwacji - klient lub wycieczka nie istnieje.");
        }
    }

    // Metoda do serializacji danych biura podróży do pliku XML
    public void ZapiszDoPliku(string nazwaPliku)
    {
        try
        {
            using (FileStream fs = new FileStream(nazwaPliku, FileMode.Create))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(BiuroPodrozy));
                serializer.Serialize(fs, this);
            }
            Console.WriteLine("Zapisano dane do pliku.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Błąd podczas zapisywania do pliku: {ex.Message}");
        }
    }

    // Metoda do deserializacji danych biura podróży z pliku XML
    public static BiuroPodrozy WczytajZPliku(string nazwaPliku)
    {
        using (FileStream fs = new FileStream(nazwaPliku, FileMode.Open))
        {
            XmlSerializer serializer = new XmlSerializer(typeof(BiuroPodrozy));
            return (BiuroPodrozy)serializer.Deserialize(fs);
        }
    }

    // Implementacja interfejsu ICloneable
    public object Clone()
    {
        BiuroPodrozy clonedBiuroPodrozy = new BiuroPodrozy();

        // Klonowanie listy klientów
        clonedBiuroPodrozy.klienci = new List<Klient>(klienci.Select(k => (Klient)k.Clone()));

        // Klonowanie listy wycieczek
        clonedBiuroPodrozy.wycieczki = new List<Wycieczka>(wycieczki.Select(w => (Wycieczka)w.Clone()));

        // Klonowanie listy przewodników
        clonedBiuroPodrozy.przewodnicy = new List<Przewodnik>(przewodnicy.Select(p => (Przewodnik)p.Clone()));

        // Klonowanie rezerwacji
        clonedBiuroPodrozy.rezerwacje = (Rezerwacje)rezerwacje.Clone();

        return clonedBiuroPodrozy;
    }
    // Dodajemy nową metodę 'UsunRezerwacje', która będzie wywoływać metodę o tej samej nazwie w klasie 'Rezerwacje'
    public bool UsunRezerwacjePoNumerzeTelefonu(string numerTelefonu)
    {
        return rezerwacje.UsunRezerwacjePoNumerzeTelefonu(numerTelefonu);
    }

}
